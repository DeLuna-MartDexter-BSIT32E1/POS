﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPOSmaindashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPOSmaindashboard))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MANAGEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.USERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PRODUCTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TRANSACTIONSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.POINTOFSALEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SALESREPORTSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SALESREPORTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActivityLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ACTIVITYLOGToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.USERLOGSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOGOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblaccesslevel = New System.Windows.Forms.Label()
        Me.lblusername = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.CornflowerBlue
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.Left
        Me.MenuStrip1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MANAGEToolStripMenuItem, Me.TRANSACTIONSToolStripMenuItem, Me.SALESREPORTSToolStripMenuItem, Me.ActivityLogToolStripMenuItem, Me.ACTIVITYLOGToolStripMenuItem1, Me.LOGOUTToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(130, 510)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MANAGEToolStripMenuItem
        '
        Me.MANAGEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.USERToolStripMenuItem, Me.PRODUCTToolStripMenuItem})
        Me.MANAGEToolStripMenuItem.Name = "MANAGEToolStripMenuItem"
        Me.MANAGEToolStripMenuItem.Size = New System.Drawing.Size(123, 23)
        Me.MANAGEToolStripMenuItem.Text = "MANAGE"
        '
        'USERToolStripMenuItem
        '
        Me.USERToolStripMenuItem.Name = "USERToolStripMenuItem"
        Me.USERToolStripMenuItem.Size = New System.Drawing.Size(180, 24)
        Me.USERToolStripMenuItem.Text = "USER"
        '
        'PRODUCTToolStripMenuItem
        '
        Me.PRODUCTToolStripMenuItem.Name = "PRODUCTToolStripMenuItem"
        Me.PRODUCTToolStripMenuItem.Size = New System.Drawing.Size(180, 24)
        Me.PRODUCTToolStripMenuItem.Text = "PRODUCT"
        '
        'TRANSACTIONSToolStripMenuItem
        '
        Me.TRANSACTIONSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.POINTOFSALEToolStripMenuItem})
        Me.TRANSACTIONSToolStripMenuItem.Name = "TRANSACTIONSToolStripMenuItem"
        Me.TRANSACTIONSToolStripMenuItem.Size = New System.Drawing.Size(123, 23)
        Me.TRANSACTIONSToolStripMenuItem.Text = "TRANSACTIONS"
        '
        'POINTOFSALEToolStripMenuItem
        '
        Me.POINTOFSALEToolStripMenuItem.Name = "POINTOFSALEToolStripMenuItem"
        Me.POINTOFSALEToolStripMenuItem.Size = New System.Drawing.Size(180, 24)
        Me.POINTOFSALEToolStripMenuItem.Text = "POINT OF SALE"
        '
        'SALESREPORTSToolStripMenuItem
        '
        Me.SALESREPORTSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SALESREPORTToolStripMenuItem})
        Me.SALESREPORTSToolStripMenuItem.Name = "SALESREPORTSToolStripMenuItem"
        Me.SALESREPORTSToolStripMenuItem.Size = New System.Drawing.Size(123, 23)
        Me.SALESREPORTSToolStripMenuItem.Text = "REPORTS"
        '
        'SALESREPORTToolStripMenuItem
        '
        Me.SALESREPORTToolStripMenuItem.Name = "SALESREPORTToolStripMenuItem"
        Me.SALESREPORTToolStripMenuItem.Size = New System.Drawing.Size(180, 24)
        Me.SALESREPORTToolStripMenuItem.Text = "SALES REPORT"
        '
        'ActivityLogToolStripMenuItem
        '
        Me.ActivityLogToolStripMenuItem.Name = "ActivityLogToolStripMenuItem"
        Me.ActivityLogToolStripMenuItem.Size = New System.Drawing.Size(123, 4)
        '
        'ACTIVITYLOGToolStripMenuItem1
        '
        Me.ACTIVITYLOGToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.USERLOGSToolStripMenuItem})
        Me.ACTIVITYLOGToolStripMenuItem1.Name = "ACTIVITYLOGToolStripMenuItem1"
        Me.ACTIVITYLOGToolStripMenuItem1.Size = New System.Drawing.Size(123, 23)
        Me.ACTIVITYLOGToolStripMenuItem1.Text = "ACTIVITY LOG"
        '
        'USERLOGSToolStripMenuItem
        '
        Me.USERLOGSToolStripMenuItem.Name = "USERLOGSToolStripMenuItem"
        Me.USERLOGSToolStripMenuItem.Size = New System.Drawing.Size(153, 24)
        Me.USERLOGSToolStripMenuItem.Text = "USER LOGS"
        '
        'LOGOUTToolStripMenuItem
        '
        Me.LOGOUTToolStripMenuItem.Name = "LOGOUTToolStripMenuItem"
        Me.LOGOUTToolStripMenuItem.Size = New System.Drawing.Size(123, 23)
        Me.LOGOUTToolStripMenuItem.Text = "LOGOUT"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(133, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(810, 510)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'lblaccesslevel
        '
        Me.lblaccesslevel.AutoSize = True
        Me.lblaccesslevel.BackColor = System.Drawing.Color.Transparent
        Me.lblaccesslevel.Location = New System.Drawing.Point(32, 474)
        Me.lblaccesslevel.Name = "lblaccesslevel"
        Me.lblaccesslevel.Size = New System.Drawing.Size(56, 13)
        Me.lblaccesslevel.TabIndex = 17
        Me.lblaccesslevel.Text = "AccessLvl"
        '
        'lblusername
        '
        Me.lblusername.AutoSize = True
        Me.lblusername.BackColor = System.Drawing.Color.Transparent
        Me.lblusername.Location = New System.Drawing.Point(32, 454)
        Me.lblusername.Name = "lblusername"
        Me.lblusername.Size = New System.Drawing.Size(55, 13)
        Me.lblusername.TabIndex = 18
        Me.lblusername.Text = "Username"
        '
        'frmPOSmaindashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(944, 510)
        Me.Controls.Add(Me.lblaccesslevel)
        Me.Controls.Add(Me.lblusername)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmPOSmaindashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmPOSmaindashboard"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MANAGEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents USERToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PRODUCTToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TRANSACTIONSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents POINTOFSALEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SALESREPORTSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SALESREPORTToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ActivityLogToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ACTIVITYLOGToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents USERLOGSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LOGOUTToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblaccesslevel As Label
    Friend WithEvents lblusername As Label
End Class
