﻿Imports System.Data.OleDb

Public Class frmLoginForm
    Private Sub frmLoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
    End Sub
    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        If String.IsNullOrEmpty(txtusername.Text) OrElse String.IsNullOrEmpty(txtpassword.Text) Then
            MsgBox("Please fill in all required fields", MsgBoxStyle.Critical)
            Return
        End If

        Dim accountExists As Boolean = CheckAccountExists(txtusername.Text)

        If accountExists Then
            sql = "Select * from tblAccounts where Username='" & txtusername.Text & "' and Password='" & txtpassword.Text & "'"
            cmd = New OleDbCommand(sql, cn)
            dr = cmd.ExecuteReader

            If dr.Read = True Then
                Dim acctStatus As String = dr("Status").ToString()
                If acctStatus = "Active" Then
                    Globals.accesslevel = dr("Accesslevel")
                    Globals.Username = dr("Username")
                    Call savelogintime()
                    MsgBox("Login in Success", MsgBoxStyle.Information)
                    frmPOSmaindashboard.ShowDialog()
                    Me.Hide()
                ElseIf acctStatus = "Disable" Then
                    MsgBox("Your account is disabled. You can't login.", MsgBoxStyle.Critical)
                Else
                    MsgBox("Unknown account status. Please contact support.", MsgBoxStyle.Critical)
                End If
            Else
                MsgBox("Login Failed", MsgBoxStyle.Critical)
                lblattempts.Text = lblattempts.Text - 1
                If lblattempts.Text = "0" Then
                    MsgBox("You reached the maximum attempt limits", MsgBoxStyle.Critical)
                    Call DisabledAccount()
                    btnlogin.Enabled = False
                End If
            End If
        Else
            MsgBox("Account doesn't exist", MsgBoxStyle.Critical)
        End If
    End Sub
    Private Function CheckAccountExists(username As String) As Boolean

        Dim accountExists As Boolean = False

        sql = "SELECT COUNT(*) FROM tblAccounts WHERE Username = @Username"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@Username", username)
        Dim count As Integer = CInt(cmd.ExecuteScalar())
        If count > 0 Then
            accountExists = True
        End If
        Return accountExists
    End Function
    Private Sub DisabledAccount()
        sql = "Update tblAccounts SET Status=@Status where Username=@Username"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@Status", "Disabled")
            .Parameters.AddWithValue("@Username", txtusername.Text)
            .ExecuteNonQuery()
        End With
        MsgBox("Your Account is Disabled, Contact Administrator To re-enable account", MsgBoxStyle.Exclamation, "Information")
    End Sub
    Public Sub savelogintime()
        Dim username As String = Globals.Username
        Dim accesslvl As String = Globals.accesslevel
        sql = "Insert into tblUserLogs (Username,Accesslevel,Datex,TimeIn,TimeOut)values(@Username,@Accesslevel,@Datex,@TimeIn,@TimeOut)"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@Username", username)
            .Parameters.AddWithValue("@Accesslevel", accesslvl)
            .Parameters.AddWithValue("@Datex", Now.ToShortDateString)
            .Parameters.AddWithValue("@TimeIn", Now.ToShortTimeString)
            .Parameters.AddWithValue("@TimeOut", "Still logged in")
            .ExecuteNonQuery()
        End With
    End Sub
    Private Sub txtusername_TextChanged(sender As Object, e As EventArgs) Handles txtusername.TextChanged
        sql = "SELECT Accesslevel from tblAccounts where Username ='" & txtusername.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            lblaccesslevel.Text = dr(0).ToString
        Else
            lblaccesslevel.Text = "-"
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        frmCreationofAccount.ShowDialog()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            ' Code to execute when the CheckBox is checked
            txtpassword.PasswordChar = ""
            txtpassword.UseSystemPasswordChar = False
        Else
            ' Code to execute when the CheckBox is unchecked
            txtpassword.PasswordChar = "●"
            txtpassword.UseSystemPasswordChar = True
        End If
    End Sub
End Class