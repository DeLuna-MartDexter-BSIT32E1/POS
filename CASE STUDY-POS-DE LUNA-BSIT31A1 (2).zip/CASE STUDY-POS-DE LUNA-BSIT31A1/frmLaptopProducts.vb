﻿Imports System.Data.OleDb
Imports System.Diagnostics.Eventing.Reader
Public Class frmLaptopProducts
    Private Sub frmLaptopProducts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call LoadProducts()
        Call disableupdatebtn()
        Call getCategory()
        Call GetTotalProducts()
    End Sub

    Private Sub LoadProducts()
        sql = "Select * from qryLaptopProducts"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        Dim x As ListViewItem
        ListView1.Items.Clear()
        Do While dr.Read = True
            x = New ListViewItem(dr(0).ToString) 'product code
            x.SubItems.Add(dr(1).ToString) 'name
            x.SubItems.Add(dr(2).ToString) 'description
            x.SubItems.Add(dr(3).ToString) 'category
            x.SubItems.Add("₱" & Format(dr(4).ToString)) 'Amount
            x.SubItems.Add(dr(5).ToString) 'Qty
            x.SubItems.Add(dr(6).ToString) 'critical level
            x.SubItems.Add(dr(7).ToString) 'status
            ListView1.Items.Add(x)
        Loop
    End Sub
    Private Sub cleartext()
        txtPCode.Clear()
        txtPName.Clear()
        txtPdesc.Clear()
        cboCategory.Text = ""
        cboStatus.SelectedItem = ""
        txtAmount.Clear()
        txtcritical.Clear()
        txtQty.Clear()
    End Sub


    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        If String.IsNullOrEmpty(txtPName.Text) OrElse
        String.IsNullOrEmpty(cboCategory.Text) OrElse
        String.IsNullOrEmpty(txtAmount.Text) OrElse
        String.IsNullOrEmpty(txtQty.Text) OrElse
        String.IsNullOrEmpty(txtcritical.Text) OrElse
        String.IsNullOrEmpty(cboStatus.Text) Then

            MessageBox.Show("Please fill in all the required fields.", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Stop further execution
        Else
            ' Generate a new ProductCode by incrementing the maximum existing ProductCode
            Dim newProductCode As Integer = GetNextProductCode()

            sql = "INSERT INTO tblLaptopProducts ([ProductCode],[ProductName],[ProductDetails],[Category],[Amount],[Quantity],[Criticallevel],[Status]) VALUES (@ProductCode, @ProductName, @ProductDetails, @Category, @Amount, @Quantity, @Criticallevel, @Status)"
            cmd = New OleDbCommand(sql, cn)

            With cmd
                .Parameters.AddWithValue("@ProductCode", newProductCode)
                .Parameters.AddWithValue("@ProductName", txtPName.Text)
                .Parameters.AddWithValue("@ProductDetails", txtPdesc.Text)
                .Parameters.AddWithValue("@Category", cboCategory.Text)
                .Parameters.AddWithValue("@Amount", txtAmount.Text)
                .Parameters.AddWithValue("@Quantity", txtQty.Text)
                .Parameters.AddWithValue("@Criticallevel", txtcritical.Text)
                .Parameters.AddWithValue("@Status", cboStatus.Text)
                .ExecuteNonQuery()
            End With

            MsgBox("New Product Successfully Saved!!", MsgBoxStyle.Information)
        End If

        Call cleartext()
        Call LoadProducts()
    End Sub
    Private Function GetNextProductCode() As Integer
        Dim nextProductCode As Integer = 100

        ' Retrieve the maximum existing ProductCode
        sql = "SELECT MAX(ProductCode) FROM tblLaptopProducts"
        cmd = New OleDbCommand(sql, cn)
        Dim maxProductCode As Object = cmd.ExecuteScalar()

        If maxProductCode IsNot DBNull.Value Then
            nextProductCode = Convert.ToInt32(maxProductCode) + 1
        End If

        Return nextProductCode
    End Function
    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        Call cleartext()
        Call disableaddbtn()
        Call disableupdatebtn()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        If ListView1.SelectedItems.Count > 0 Then
            txtPCode.Text = ListView1.SelectedItems(0).SubItems(0).Text
            'txtPName.Text = ListView1.SelectedItems(0).SubItems(1).Text
            'txtPdesc.Text = ListView1.SelectedItems(0).SubItems(2).Text
            'cboCategory.Text = ListView1.SelectedItems(0).SubItems(3).Text
            'txtAmount.Text = ListView1.SelectedItems(0).SubItems(4).Text
            'txtQty.Text = ListView1.SelectedItems(0).SubItems(5).Text
            'txtcritical.Text = ListView1.SelectedItems(0).SubItems(6).Text
            'cboStatus.Text = ListView1.SelectedItems(0).SubItems(7).Text

            Call disableaddbtn()
            Call disableupdatebtn()
        End If
    End Sub
    Private Sub getCategory()
        sql = "Select distinct Category from tblLaptopCategory"
        cmd = New OleDbCommand(sql, cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        cboCategory.DataSource = dt
        cboCategory.DisplayMember = "Category"
    End Sub


    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        If String.IsNullOrEmpty(txtPName.Text) OrElse
              String.IsNullOrEmpty(cboCategory.Text) OrElse
              String.IsNullOrEmpty(txtAmount.Text) OrElse
              String.IsNullOrEmpty(txtQty.Text) OrElse
              String.IsNullOrEmpty(txtcritical.Text) OrElse
              String.IsNullOrEmpty(cboStatus.Text) Then

            MessageBox.Show("Please fill in all the required fields.", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Stop further execution
        Else
            sql = "Update tblLaptopProducts Set [ProductName]=[@ProductName],[ProductDetails]=[@ProductDetails],[Category]=[@Category],[Amount]=[@Amount],[Quantity]=[@Quantity],[Criticallevel]=[@CriticalLevel],[Status]=[@Status] where [ProductCode]=[@ProductCode]"

            cmd = New OleDbCommand(sql, cn)
            With cmd
                .Parameters.AddWithValue("[@ProductName]", txtPName.Text) 'name
                .Parameters.AddWithValue("[@ProdDetails]", txtPdesc.Text) 'desc
                .Parameters.AddWithValue("[@Category]", cboCategory.Text) 'category
                .Parameters.AddWithValue("[@Amount]", txtAmount.Text) 'amount
                .Parameters.AddWithValue("[@Quantity]", txtQty.Text) 'qty
                .Parameters.AddWithValue("[@CriticalLevel]", txtcritical.Text) 'crit level
                .Parameters.AddWithValue("[@Status", cboStatus.Text) 'status
                .Parameters.AddWithValue("[@ProductCode]", txtPCode.Text) 'prod code
                .ExecuteNonQuery()

            End With
            MsgBox("Product Successfully Updated!!", MsgBoxStyle.Information)
        End If
        Call cleartext()
        Call LoadProducts()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Dim searchText As String = txtSearch.Text.ToLower()
        If searchText.Trim() <> String.Empty Then
            For Each item As ListViewItem In ListView1.Items
                ' Compare the text of each ListViewItem to the search text
                If item.Text.ToLower().Contains(searchText) Then
                    ' If it matches, make the item visible
                    item.EnsureVisible()
                    item.Selected = True ' Optionally select the item
                Else
                    ' If it doesn't match, hide the item
                    item.Selected = False ' Optionally deselect the item
                    item.EnsureVisible() ' Optionally, ensure the item is not visible
                End If
            Next
        Else
            ' If the search text is empty, make all items visible
            For Each item As ListViewItem In ListView1.Items
                item.Selected = False ' Optionally deselect the item
                item.EnsureVisible() ' Optionally, ensure the item is visible
            Next
        End If
    End Sub
    Private Sub GetTotalProducts()
        sql = "Select sum(Quantity) from qryLaptopProducts"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            lblTotal.Text = dr(0)
        End If
    End Sub
    Private Sub disableaddbtn()
        If String.IsNullOrEmpty(txtPCode.Text) Then
            btnadd.Enabled = True
            cboStatus.Enabled = True
        Else
            btnadd.Enabled = False ' Enable the button when txtgymID is not empty
            cboStatus.Enabled = False
        End If
    End Sub

    Private Sub disableupdatebtn()
        If Not String.IsNullOrEmpty(txtPCode.Text) Then
            btnupdate.Enabled = True ' Re-enable the button 
        Else
            btnupdate.Enabled = False ' Disable the button
        End If
    End Sub
    Private Sub txtPCode_TextChanged(sender As Object, e As EventArgs) Handles txtPCode.TextChanged
        If Not String.IsNullOrEmpty(txtPCode.Text) Then
            Call disableaddbtn()
            Call disableupdatebtn()
            sql = "SELECT * FROM qryLaptopProducts WHERE ProductCode = @ProductCode"
            cmd = New OleDbCommand(sql, cn)

            Dim pcode As Integer
            If Integer.TryParse(txtPCode.Text, pcode) Then
                cmd.Parameters.AddWithValue("@ProductCode", pcode)
                dr = cmd.ExecuteReader
                If dr.Read Then
                    txtPCode.Text = dr("ProductCode").ToString
                    txtPName.Text = dr("ProductName").ToString
                    txtPdesc.Text = dr("ProductDetails").ToString
                    cboCategory.Text = dr("Category").ToString
                    txtAmount.Text = dr("Amount").ToString
                    txtQty.Text = dr("Quantity").ToString
                    txtcritical.Text = dr("Criticallevel").ToString
                    cboStatus.Text = dr("Status").ToString

                    ' Add the Category to the ComboBox items if not already present
                    'If Not cboCategory.Items.Contains(dr("Category").ToString) Then
                    '    cboCategory.Items.Add(dr("Category").ToString)
                    'End If
                End If

            Else
                ' Handle the case where the input is not a valid integer
                txtPName.Text = ""
                txtPdesc.Text = ""
                txtAmount.Text = ""
                txtQty.Text = ""
                txtcritical.Text = ""
            End If
        Else
            ' Handle the case where the textbox is empty
            txtPName.Text = ""
            txtPdesc.Text = ""
            txtAmount.Text = ""
            txtQty.Text = ""
            txtcritical.Text = ""
        End If
    End Sub

    Private Sub txtAmount_TextChanged(sender As Object, e As EventArgs) Handles txtAmount.TextChanged
        ' Iterate through each character in the TextBox text
        For Each c As Char In txtAmount.Text
            ' Check if the character is not a digit
            If Not Char.IsDigit(c) Then
                ' If it's not a digit, remove the character from the TextBox text
                txtAmount.Text = txtAmount.Text.Remove(txtAmount.Text.IndexOf(c), 1)
            End If
        Next
    End Sub

    Private Sub txtQty_TextChanged(sender As Object, e As EventArgs) Handles txtQty.TextChanged
        ' Iterate through each character in the TextBox text
        For Each c As Char In txtQty.Text
            ' Check if the character is not a digit
            If Not Char.IsDigit(c) Then
                ' If it's not a digit, remove the character from the TextBox text
                txtQty.Text = txtQty.Text.Remove(txtQty.Text.IndexOf(c), 1)
            End If
        Next
        ' Convert txtQty.Text to an integer
        Dim qty As Integer
        If Integer.TryParse(txtQty.Text, qty) Then
            If qty = 0 Then
                cboStatus.SelectedItem = "OUT OF STOCK"
            ElseIf txtcritical.Text <> "" AndAlso Integer.TryParse(txtcritical.Text, Nothing) Then
                Dim criticalLevel As Integer = Integer.Parse(txtcritical.Text)
                If qty <= criticalLevel Then
                    cboStatus.SelectedItem = "CRITICAL LEVEL"
                Else
                    cboStatus.SelectedItem = "AVAILABLE"
                End If
            End If
        End If

    End Sub
    Private Sub txtcritical_TextChanged(sender As Object, e As EventArgs) Handles txtcritical.TextChanged
        For Each c As Char In txtcritical.Text
            ' Check if the character is not a digit
            If Not Char.IsDigit(c) Then
                ' If it's not a digit, remove the character from the TextBox text
                txtcritical.Text = txtcritical.Text.Remove(txtcritical.Text.IndexOf(c), 1)
            End If
        Next
    End Sub


End Class
