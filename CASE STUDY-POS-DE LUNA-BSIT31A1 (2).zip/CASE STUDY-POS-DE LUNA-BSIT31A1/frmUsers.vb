﻿Imports System.Data.OleDb

Public Class frmUsers
    Private Sub frmUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call LoadUsers()
        Call GetTotalUsers()
        Call disablecreateaccbtn()
        Call disableupdatebtn()
    End Sub

    Private Sub LoadUsers()
        sql = "Select * from tblAccounts"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        Dim x As ListViewItem
        ListView1.Items.Clear()
        Do While dr.Read = True
            x = New ListViewItem(dr(0).ToString)
            x.SubItems.Add(dr(1).ToString)
            x.SubItems.Add(dr(2).ToString)
            x.SubItems.Add(dr(3).ToString)
            x.SubItems.Add(dr(4).ToString)
            x.SubItems.Add(dr(5).ToString)
            x.SubItems.Add(dr(6).ToString)
            ListView1.Items.Add(x)
        Loop
    End Sub

    Private Sub GetTotalUsers()
        sql = "Select count(Status) from tblAccounts"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            lblTotal.Text = dr(0)
        End If
    End Sub
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        If ListView1.SelectedItems.Count > 0 Then
            txtuserId.Text = ListView1.SelectedItems(0).SubItems(0).Text
        End If
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Dim searchText As String = txtSearch.Text.ToLower()
        If searchText.Trim() <> String.Empty Then
            For Each item As ListViewItem In ListView1.Items
                ' Compare the text of each ListViewItem to the search text
                If item.Text.ToLower().Contains(searchText) Then
                    ' If it matches, make the item visible
                    item.EnsureVisible()
                    item.Selected = True ' Optionally select the item
                Else
                    ' If it doesn't match, hide the item
                    item.Selected = False ' Optionally deselect the item
                    item.EnsureVisible() ' Optionally, ensure the item is not visible
                End If
            Next
        Else
            ' If the search text is empty, make all items visible
            For Each item As ListViewItem In ListView1.Items
                item.Selected = False ' Optionally deselect the item
                item.EnsureVisible() ' Optionally, ensure the item is visible
            Next
        End If
    End Sub

    Private Sub txtuserId_TextChanged(sender As Object, e As EventArgs) Handles txtuserId.TextChanged
        sql = "SELECT Username,Password,Accesslevel,Lastname,Firstname,Status FROM tblAccounts WHERE User_ID = @User_ID"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@StaffsID", Convert.ToInt32(txtuserId.Text)) ' Assuming ID is an integer in the database
        dr = cmd.ExecuteReader
        If dr.Read Then
            txtusername.Text = dr("Username").ToString
            txtpassword.Text = dr("Password").ToString
            cboAccess.Text = dr("Accesslevel").ToString
            txtlastname.Text = dr("Lastname").ToString
            txtfirstname.Text = dr("Firstname").ToString
            cbostatus.Text = dr("Status").ToString
        End If
        Call disablecreateaccbtn()
        Call disableupdatebtn()
    End Sub
    Private Sub clearbox()
        txtuserId.Text = "0"
        txtusername.Text = ""
        txtpassword.Text = ""
        txtconfirmpassword.Text = ""
        cboAccess.SelectedItem = ""
        txtlastname.Text = ""
        txtfirstname.Text = ""
        cbostatus.SelectedItem = ""
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        Call clearbox()
    End Sub
    Private Sub disablecreateaccbtn()
        If txtuserId.Text = "0" Then
            btncreate.Enabled = True
        Else
            btncreate.Enabled = False
        End If
    End Sub

    Private Sub disableupdatebtn()
        If Not txtuserId.Text = "0" Then
            btnupdate.Enabled = True ' Re-enable the button 
            txtconfirmpassword.Enabled = False
        Else
            btnupdate.Enabled = False ' Disable the button
            txtconfirmpassword.Enabled = True
        End If
    End Sub

    Private Sub btnnew_Click(sender As Object, e As EventArgs) Handles btncreate.Click
        sql = "Select username from tblAccounts where Username='" & txtusername.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.HasRows = True Then
            MsgBox("Username already exist", MsgBoxStyle.Information, "Error")
        ElseIf txtpassword.Text <> txtconfirmpassword.Text Then
            MsgBox("Password and Confirmed Password Mismatched", MsgBoxStyle.Critical, "Error")
        ElseIf txtpassword.TextLength < 6 And txtconfirmpassword.TextLength < 6 Then
            MsgBox("Password is less than 6 characters", MsgBoxStyle.Critical, "Error")
        Else
            If String.IsNullOrEmpty(txtfirstname.Text) OrElse
               String.IsNullOrEmpty(txtlastname.Text) OrElse
               String.IsNullOrEmpty(txtusername.Text) OrElse
               String.IsNullOrEmpty(txtpassword.Text) OrElse
               String.IsNullOrEmpty(txtconfirmpassword.Text) OrElse
               String.IsNullOrEmpty(cboAccess.Text) Then
                MessageBox.Show("Please fill in all the required fields.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return ' Stop further execution
            Else
                Call createaccount()
                Call clearbox()
                Call disablecreateaccbtn()
                Call disableupdatebtn()
            End If
        End If
    End Sub
    Private Sub createaccount()
        sql = "INSERT INTO tblAccounts ([Username],[Password],[Accesslevel],[Lastname],[Firstname],[Status]) VALUES (@Username, @Password, @Accesslevel, @Lastname, @Firstname, @Status)"
        cmd = New OleDbCommand(sql, cn)

        With cmd
            .Parameters.AddWithValue("@Username", txtusername.Text)
            .Parameters.AddWithValue("@Password", txtpassword.Text)
            .Parameters.AddWithValue("@Accesslevel", cboAccess.Text)
            .Parameters.AddWithValue("@Lastname", txtlastname.Text)
            .Parameters.AddWithValue("@Firstname", txtfirstname.Text)
            .Parameters.AddWithValue("@Status", "Active")
            .ExecuteNonQuery()
        End With

        MsgBox("Account Successfully created", MsgBoxStyle.Information, "Information")
    End Sub
    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        sql = "UPDATE tblAccounts SET Username=@Username, [Password]=@Password, Accesslevel=@Accesslevel, Lastname=@Lastname, Firstname=@Firstname, Status=@Status WHERE UserID=@UserID"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@Username", txtusername.Text)
            .Parameters.AddWithValue("@Password", txtpassword.Text)
            .Parameters.AddWithValue("@Accesslevel", cboAccess.Text)
            .Parameters.AddWithValue("@Lastname", txtlastname.Text)
            .Parameters.AddWithValue("@Firstname", txtfirstname.Text)
            .Parameters.AddWithValue("@Status", cbostatus.Text)
            .Parameters.AddWithValue("@UserID", txtuserId.Text)
            .ExecuteNonQuery()
        End With

        MsgBox("Account Successfully updated", MsgBoxStyle.Information, "Information")
        Call clearbox()
        Call LoadUsers()
        Call disablecreateaccbtn()
        Call disableupdatebtn()
    End Sub
End Class