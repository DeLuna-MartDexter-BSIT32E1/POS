﻿Imports System.Data.OleDb
Imports System.Data.SqlTypes
Module Globals
    Public accesslevel As String = ""
    Public Username As String = ""
End Module
Public Class frmPOSmaindashboard

    Private Sub frmPOSmaindashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call ButtonVisibility()
        'Call POSlogin.savelogintime()
        frmLoginForm.lblattempts.Text = 3 'balik sa 3 attempts if login success
        lblusername.Text = Globals.Username
        lblaccesslevel.Text = Globals.accesslevel
    End Sub
    Private Sub ButtonVisibility()
        Select Case Globals.accesslevel
            Case "Administrator"
                'allow lahat
            Case "Cashier"
                TRANSACTIONSToolStripMenuItem.Enabled = True
                MANAGEToolStripMenuItem.Enabled = False
                SALESREPORTSToolStripMenuItem.Enabled = False
            Case "Inventory"
                USERToolStripMenuItem.Enabled = False
                TRANSACTIONSToolStripMenuItem.Enabled = False
                SALESREPORTSToolStripMenuItem.Enabled = False
        End Select
    End Sub
    Private Sub USERToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles USERToolStripMenuItem.Click
        frmUsers.Show()
    End Sub
    Private Sub SALESREPORTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SALESREPORTToolStripMenuItem.Click
        frmSalesReport.Show()
    End Sub

    Private Sub POINTOFSALEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles POINTOFSALEToolStripMenuItem.Click
        frmPOSdashhboard.Show()
    End Sub

    Private Sub PRODUCTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PRODUCTToolStripMenuItem.Click
        frmLaptopProducts.Show()
    End Sub

    Private Sub USERLOGSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles USERLOGSToolStripMenuItem.Click
        frmUserlogs.Show()
    End Sub

    Private Sub LOGOUTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LOGOUTToolStripMenuItem.Click
        If MsgBox("You sure you want to logout?", vbQuestion + vbYesNo, "Information") = vbYes Then
            MsgBox("You are now logging out.", MsgBoxStyle.Information, "Information")
        End If
        Call savelogouttime()
        frmLoginForm.Close()
        Me.Close()
    End Sub

    Private Sub Updatelogs()
        sql = "Select Username from tblUserLogs where Username=@Username and Datex=@Datex and TimeOut=@TimeOut"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@Username", lblusername.Text)
            .Parameters.AddWithValue("@Datex", Now.ToShortDateString)
            .Parameters.AddWithValue("@TimeOut", "Still logged in")
        End With
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            savelogouttime()
        End If
        dr.Close()
    End Sub
    Private Sub savelogouttime()
        sql = "Update tblUserLogs set TimeOut=@TimeOut where Datex=@Datex and Username=@Username and TimeOut='Still logged in'"

        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@TimeOut", Now.ToShortTimeString)
            .Parameters.AddWithValue("@Datex", Now.ToShortDateString)
            .Parameters.AddWithValue("@Username", lblusername.Text)
            .ExecuteNonQuery()
        End With
    End Sub

End Class