﻿Imports System.Data.OleDb
Imports System.Runtime.CompilerServices.RuntimeHelpers
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip
Public Class frmPOSdashhboard

    Private Sub frmPOSdashhboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call getTransactionNo()
        Call loadMOP()
        Call reenablecbomop()
        Call disablebtnsavetransaction()
        cboDiscount.SelectedItem = "None"
        btnaddproduct.Enabled = False
    End Sub
    Private Sub getTransactionNo()
        sql = "Select Transac_No from tblTransaction order by Transac_No desc"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            lblTransNo.Text = Val(dr(0)) + 1
        Else
            lblTransNo.Text = 1000
        End If
    End Sub
    Private Sub getreferencefno()
        sql = "Select Reference_No from tblPayment order by Reference_No desc"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            txtref.Text = Val(dr(0)) + 1
        Else
            txtref.Text = 1000
        End If
    End Sub
    Private Sub btncanceltrans_Click(sender As Object, e As EventArgs) Handles btncanceltrans.Click
        If MsgBox("You sure you want to cancel transaction?", vbQuestion + vbYesNo, "Information") = vbYes Then
            MsgBox("Transaction is now canceled.", MsgBoxStyle.Information, "Information")
            'code
            Call cancelclearbox()
            Call resetCurrency()
            ListView2.Items.Clear()
            Call reenablecbomop()
            Call disablebtnsavetransaction()
        End If
    End Sub

    Private Sub ListView2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView2.SelectedIndexChanged
        If ListView2.SelectedItems.Count > 0 Then
            txtproductcode.Text = ListView2.SelectedItems(0).SubItems(0).Text
        End If
    End Sub
    Private Sub txtproductcode_TextChanged(sender As Object, e As EventArgs) Handles txtproductcode.TextChanged
        ' Iterate through each character in the TextBox text
        For Each c As Char In txtproductcode.Text
            ' Check if the character is not a digit
            If Not Char.IsDigit(c) Then
                ' If it's not a digit, remove the character from the TextBox text
                txtproductcode.Text = txtproductcode.Text.Remove(txtproductcode.Text.IndexOf(c), 1)
            End If
        Next
        sql = "Select Productname,Amount,Quantity,Criticallevel,Status from qryLaptopProducts where ProductCode='" & txtproductcode.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            txtproductname.Text = dr(0)
            txtamount.Text = dr(1)
            txtquantity.Text = dr(2)
            txtcritlevel.Text = dr(3)
            txtstatus.Text = dr(4)
        Else
            clearbox()
        End If
    End Sub
    Private Sub clearbox()
        txtproductname.Text = ""
        txtamount.Text = ""
        txtquantity.Text = ""
        txtcritlevel.Text = ""
        txtstatus.Text = ""
    End Sub
    Private Sub cancelclearbox()
        txtproductcode.Text = ""
        txtproductname.Text = ""
        txtamount.Text = ""
        txtquantity.Text = ""
        txtcritlevel.Text = ""
        txtstatus.Text = ""
    End Sub
    Dim a As String 'amount var
    Dim l As ListViewItem 'listview
    Private Sub btnaddproduct_Click(sender As Object, e As EventArgs) Handles btnaddproduct.Click
        Dim amount As Double
        a = InputBox("Enter number of products?", "Add Product")
        If String.IsNullOrEmpty(a) Or a = "0" Then
            'code
        Else
            If Val(a) > Val(txtquantity.Text) Then
                MsgBox("Number of products is greater than the available products", MsgBoxStyle.Exclamation, "Re-enter number of products")
            Else
                txtquantity.Text = Val(txtquantity.Text) - Val(a)
                amount = Val(txtamount.Text) * Val(a)
                l = Me.ListView2.Items.Add(txtproductcode.Text) 'product code
                l.SubItems.Add(txtproductname.Text) 'product name
                l.SubItems.Add(txtamount.Text) 'Amount
                l.SubItems.Add(a) 'quantity from the user input
                l.SubItems.Add(amount) 'subtotal amount
                If Val(txtquantity.Text) = 0 Then 'if the quantity reaches 0
                    txtstatus.Text = "OUT OF STOCK"
                ElseIf Val(txtquantity.Text) <= Val(txtcritlevel.Text) Then 'if quantity reaches the value of critical level or lower
                    txtstatus.Text = "CRITICAL LEVEL"
                End If
            End If
        End If
        Call GetTotal()
        Call getVAT()
        Call GetTotalItem()
        Call reenablecbomop()
        Call disablebtnsavetransaction()
    End Sub
    Private Sub GetTotal()
        Const col As Integer = 4 'subTotal column
        Dim total As Integer
        Dim lvsi As ListViewItem.ListViewSubItem
        For i As Integer = 0 To ListView2.Items.Count - 1
            lvsi = ListView2.Items(i).SubItems(col)
            total += Double.Parse(lvsi.Text)
        Next
        lblTotal.Text = Format(Val(total), "0.00")
    End Sub

    Private Sub GetTotalItem()
        Const col As Integer = 3 'quantity column
        Dim total As Integer
        Dim listview As ListViewItem.ListViewSubItem
        For i As Integer = 0 To ListView2.Items.Count - 1
            listview = ListView2.Items(i).SubItems(col)
            total += Double.Parse(listview.Text)
        Next
        lblTotalItems.Text = Val(total)
    End Sub

    Private Sub btnremoveproduct_Click(sender As Object, e As EventArgs) Handles btnremoveproduct.Click
        If MsgBox("Remove Product?", vbQuestion + vbYesNo) = vbYes Then
            If ListView2.Items.Count = 0 Then
                MsgBox("No Products on the list", MsgBoxStyle.Critical, "Information")
            Else
                If ListView2.SelectedItems.Count > 0 Then
                    Dim lvalue As Integer = Integer.Parse(ListView2.SelectedItems(0).SubItems(3).Text) 'holds the value of quantity column
                    Dim newQty As Integer = lvalue + Val(txtquantity.Text) 'holds the new quantity added from the removed items in quanity column
                    txtquantity.Text = newQty 'new value of quantity
                    ListView2.Items.Remove(ListView2.FocusedItem) 'removes the item that was selected
                    If Val(txtquantity.Text) > Val(txtcritlevel.Text) Then 'if the quantity is greater than critical level the status will be available
                        txtstatus.Text = "Available"
                    End If
                    Call GetTotalItem()
                    Call GetTotal()
                    Call getVAT()
                    Call reenablecbomop()
                    Call disablebtnsavetransaction()
                End If

            End If
        End If
    End Sub
    Private Sub getVAT()
        Dim vatableSales As Double
        vatableSales = lblTotal.Text / 1.12 'THE TOTAL AMOUNT DIVIDED BY 1.12
        lblVAT.Text = Format(Val(vatableSales), "0.00")
        lblVSales.Text = Val(lblTotal.Text) - Val(lblVAT.Text) 'THE RESULT OF VAT MINUS THE TOTAL AMOUNT
        lblTotal.Text = lblTotal.Text - lblVSales.Text
    End Sub
    Private Sub resetCurrency()
        txtamountpaid.Text = "0.00"
        lblVAT.Text = "0.00"
        lblVSales.Text = "0.00"
        lblTotalItems.Text = "0"
        cboMOP.SelectedItem = vbEmpty
        lblDisc.Text = "0.00"
        txtref.Text = ""
        lblTotal.Text = "0.00"
        lblchange.Text = "0.00"
    End Sub
    Dim discountApplied As Boolean = False
    Private Sub cboDiscount_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDiscount.SelectedIndexChanged
        If cboDiscount.SelectedItem = "PWD" Or cboDiscount.SelectedItem = "Senior Citizen" Then
            If Not discountApplied Then
                lblVAT.Text = "0.00" ' VAT EXEMPT
                lblVSales.Text = "0.00" ' VAT EXEMPT 
                Call GetTotal()
                Dim discount As Double = Val(lblTotal.Text) * 0.2  ' discount value is 20% 
                lblDisc.Text = Format(discount, "0.00")
                Dim newTotal As Double = Val(lblTotal.Text) - discount ' computes the new total of the items less the discounted percentage
                lblTotal.Text = Format(newTotal, "0.00") ' new total
                Call change()
                discountApplied = True
            End If
        Else
            Call GetTotal()
            Call getVAT()
            Call change()
            discountApplied = False
        End If
    End Sub

    Private Sub disablebtnsavetransaction()
        If ListView2.Items.Count = 0 Then
            btnsavetransaction.Enabled = False
            btncanceltrans.Enabled = False
        Else
            btnsavetransaction.Enabled = True
            btncanceltrans.Enabled = True
        End If
    End Sub

    Private Sub btnsavetransaction_Click(sender As Object, e As EventArgs) Handles btnsavetransaction.Click
        If MsgBox("Save Transaction?", vbQuestion + vbYesNo) = vbYes Then

            If Val(txtamountpaid.Text) < Val(lblTotal.Text) Then
                MsgBox("Insufficient Amount Paid", MsgBoxStyle.Critical, "Please Re-Enter Payment")
            Else
                'saving transaction
                sql = "Insert into tblTransaction(Transac_No,TransacDate,TransacTime,TotalAmount,VAT,VatableSales,Discount,DiscountType,CashierName)values(@Transac_No,@TransacDate,@TransacTime,@TotalAmount,@VAT,@VatableSales,@Discount,@DiscountType,@CashierName)"
                cmd = New OleDbCommand(sql, cn)
                With cmd
                    .Parameters.AddWithValue("@Transac_No", lblTransNo.Text)
                    .Parameters.AddWithValue("@TransacDate", Date.Now.ToString("MM/dd/yyyy"))
                    .Parameters.AddWithValue("@TransacTime", Date.Now.ToString("h:mm:ss tt"))
                    .Parameters.AddWithValue("@TotalAmount", lblTotal.Text)
                    .Parameters.AddWithValue("@VAT", lblVAT.Text)
                    .Parameters.AddWithValue("@VatableSales", lblVSales.Text)
                    .Parameters.AddWithValue("@Discount", lblDisc.Text)
                    .Parameters.AddWithValue("@DiscountType", cboDiscount.Text)
                    .Parameters.AddWithValue("@CashierName", "")
                    .ExecuteNonQuery()
                End With
                'UPDATE QUANTITY
                For Each x As ListViewItem In ListView2.Items
                    sql = "update tblLaptopProducts SET Quantity=@Quantity where ProductCode = @ProductCode"
                    cmd = New OleDbCommand(sql, cn)
                    cmd.Parameters.AddWithValue("@Quantity", txtquantity.Text)
                    cmd.Parameters.AddWithValue("@ProductCode", txtproductcode.Text)
                    cmd.ExecuteNonQuery()
                Next
                'save details
                For Each i As ListViewItem In ListView2.Items
                    sql = "Insert into tblTransactionDetails(Transac_No,ProductCode,Amount,Quantity,Total)Values(@Transac_No,@ProductCode,@Amount,@Quantity,@Total)"
                    cmd = New OleDbCommand(sql, cn)
                    cmd.Parameters.AddWithValue("@Transac_No", lblTransNo.Text)
                    cmd.Parameters.AddWithValue("@ProductCode", i.Text) 'FIRST COLUMN OF THE LISTVIEW
                    cmd.Parameters.AddWithValue("@Amount", i.SubItems(2).Text) '3RD COLUMN
                    cmd.Parameters.AddWithValue("@Quantity", i.SubItems(3).Text) '4TH COLUMN
                    cmd.Parameters.AddWithValue("@Total", i.SubItems(4).Text) '5TH COLUMN
                    cmd.ExecuteNonQuery()
                Next
                'payments
                sql = "Insert into tblPayment(Transac_No,TotalAmount,AmountPaid,AmountChange,ModeofPayment,Reference_No)Values(@Transac_No,@TotalAmount,@AmountPaid,@AmountChange,@ModeofPayment,@Reference_No)"
                cmd = New OleDbCommand(sql, cn)
                cmd.Parameters.AddWithValue("@Transac_No", lblTransNo.Text)
                cmd.Parameters.AddWithValue("@TotalAmount", lblTotal.Text)
                cmd.Parameters.AddWithValue("@AmountPaid", txtamountpaid.Text)
                cmd.Parameters.AddWithValue("@AmountChange", lblchange.Text)
                cmd.Parameters.AddWithValue("@ModeofPayment", cboMOP.Text)
                cmd.Parameters.AddWithValue("@Reference_No", txtref.Text)
                cmd.ExecuteNonQuery()
                MsgBox("Transaction Successfully Saved", MsgBoxStyle.Information)
                ListView2.Items.Clear()
                Call resetCurrency()
                Call cancelclearbox()
                Call reenablecbomop()
            End If
        End If
        Call getTransactionNo()
    End Sub
    'PAYMENTS
    Private Sub loadMOP()
        'GETS THE PAYMENT MODE ON THE DATABASE TABLE
        sql = "Select distinct PaymentMode from tblPaymentMode where Status='1'"
        cmd = New OleDbCommand(sql, cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        cboMOP.DataSource = dt
        cboMOP.DisplayMember = "PaymentMode"
    End Sub
    Private Sub reenablecbomop()
        If ListView2.Items.Count = 0 Then
            cboMOP.Enabled = False
        Else
            cboMOP.Enabled = True
        End If
    End Sub
    Private Sub cboMOP_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMOP.SelectedIndexChanged
        Call reenablecbomop()

        If cboMOP.Text = "Cash" Then 'WHEN THE USER SELECT 
            txtamountpaid.Clear() 'CLEARS AMOUNT PAID
            txtamountpaid.Enabled = True 'ACCEPTS INPUT PAYMENT
            txtref.Clear()
        Else 'WHEN THE USER SELECT OTHER PAYMENT METHOD
            lblchange.Text = "0.00"
            txtamountpaid.Text = lblTotal.Text
            txtamountpaid.Enabled = False 'UNABLE TO ACCEPT INPUT PAYMENT
            Call getreferencefno()
        End If
    End Sub
    Private Sub change()
        Dim change As Double
        change = Val(txtamountpaid.Text) - Val(lblTotal.Text) 'THE TOTAL PAYMENT LESS TO THE TOTAL GRAND TOTAL
        lblchange.Text = Format(Val(change), "0.00") 'CHANGE OF THE CUSTOMER
    End Sub
    Private Sub txtamountpaid_TextChanged(sender As Object, e As EventArgs) Handles txtamountpaid.TextChanged
        If String.IsNullOrEmpty(txtamountpaid.Text) Then
            cboDiscount.Enabled = False
        Else
            cboDiscount.Enabled = True
        End If
        Call change()
    End Sub

    Private Sub btnaddmop_Click(sender As Object, e As EventArgs) Handles btnaddmop.Click
        ' Prompt the user for input
        Dim t As String = InputBox("Enter mode of payment")

        ' Check if the user clicked "Cancel"
        If Not String.IsNullOrEmpty(t) Then
            ' User entered a value, proceed with database insertion
            sql = "Insert into tblPaymentMode(PaymentMode,Status)values(@PaymentMode,@Status)"
            cmd = New OleDbCommand(sql, cn)

            With cmd
                .Parameters.AddWithValue("@PaymentMode", t)
                .Parameters.AddWithValue("@Status", "1")
                .ExecuteNonQuery()
            End With
        Else
            ' User clicked "Cancel," do nothing or provide feedback as needed
        End If
    End Sub

    Private Sub txtquantity_TextChanged(sender As Object, e As EventArgs) Handles txtquantity.TextChanged
        If String.IsNullOrEmpty(txtquantity.Text) Then 'reenable btnaddproduct
            btnaddproduct.Enabled = False
        Else
            btnaddproduct.Enabled = True

        End If
    End Sub

End Class

