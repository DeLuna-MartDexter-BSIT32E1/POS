﻿Imports System.Data.OleDb
Imports System.Runtime.CompilerServices.RuntimeHelpers
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frmPOSdashboard
    Private Sub frmPOSdashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call GetTransactionNo()
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lbldate.Text = Now.ToLongDateString
        lbltime.Text = Now.ToShortTimeString
    End Sub

    Private Sub GetTransactionNo()
        sql = "Select Transac_No from tblTransaction order by Transac_No desc"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            lblTransNo.Text = Val(dr(0)) + 1
        Else
            lblTransNo.Text = 1001
        End If
    End Sub
    Private Sub txtProductCode_TextChanged(sender As Object, e As EventArgs) Handles txtProductCode.TextChanged
        sql = "Select ProductName,Amount,Quantity,Criticallevel,Status from qryLaptopProducts where ProductCode='" & txtProductCode.Text & "' and Quantity>'0'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            txtProductName.Text = dr(0) 'product name
            txtAmount.Text = dr(1) 'amount
            txtQuanty.Text = dr(2) 'quantity
            txtCritLevel.Text = dr(3) 'critical level
            txtStatus.Text = dr(4) 'status
        Else
            'MsgBox("Items not found or Item is out of stocked", MsgBoxStyle.Critical)
            ClearText()
        End If
    End Sub
    Private Sub ClearText()
        txtProductName.Clear()
        txtAmount.Clear()
        txtCritLevel.Clear()
        txtQuanty.Clear()
        txtStatus.Text = "******"
    End Sub
    Dim l As ListViewItem
    Dim Amount As Double
    Private Sub btnAddtoCart_Click(sender As Object, e As EventArgs) Handles btnAddtoCart.Click
        Dim a As String = InputBox("Enter number of products?", "Quantity")
        If a = "" Or a = 0 Then
            MsgBox("Please enter number of products")
        Else
            If Val(a) > Val(txtQuanty.Text) Then
                MsgBox("Number of products is greater than the available products", MsgBoxStyle.Exclamation, "Re-enter number of products")
            Else
                txtQuanty.Text = Val(txtQuanty.Text) - Val(a)
                Amount = Val(txtAmount.Text) * Val(a)
                l = Me.ListView1.Items.Add(txtProductCode.Text) 'product code
                l.SubItems.Add(txtProductName.Text) 'product name
                l.SubItems.Add(txtAmount.Text) 'amount
                l.SubItems.Add(a) 'quantity from the user input
                l.SubItems.Add(Amount) 'subtotal amount
                If Val(txtQuanty.Text) = 0 Then 'if the quantity reaches 0
                    txtStatus.Text = "OUT OF STOCK"
                ElseIf Val(txtQuanty.Text) <= Val(txtCritLevel.Text) Then 'if quantity reaches the value of critical level or lower
                    txtStatus.Text = "CRITICAL LEVEL"
                End If
            End If
        End If

        GetTotal()
        GetTotalItem()
        getVAT()
    End Sub
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If MsgBox("Removed Product?", vbQuestion + vbYesNo) = vbYes Then
            If ListView1.Items.Count = 0 Then
                MsgBox("No Products on the list", MsgBoxStyle.Critical)
            Else
                If ListView1.SelectedItems.Count > 0 Then
                    Dim lvalue As Integer = Integer.Parse(ListView1.SelectedItems(0).SubItems(3).Text) 'holds the value of quantity column
                    Dim newQty As Integer = lvalue + Val(txtQuanty.Text) 'holds the new quantity added from the removed items in quanity column
                    txtQuanty.Text = newQty 'new value of quantity
                    ListView1.Items.Remove(ListView1.FocusedItem) 'removes the item that was selected
                    If Val(txtQuanty.Text) > Val(txtCritLevel.Text) Then 'if the quantity is greater than critical level the status will be available
                        txtStatus.Text = "Available"
                    End If
                    GetTotalItem()
                    GetTotal()
                    GetVAT()
                End If

            End If
        End If
    End Sub
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If MsgBox("Save Transaction?", vbQuestion + vbYesNo) = vbYes Then

            If Val(lblAmountPaid.Text) < Val(lblTotal.Text) Then
                MsgBox("Insufficient Amount Paid", MsgBoxStyle.Critical, "Please Re-Enter Payment")
            Else
                'saving transaction
                sql = "Insert into tblTransaction(Transac_No,TransacDate,TransacTime,TotalAmount,VAT,VatableSales,Discount,DiscountType,CashierName)values(@Transac_No,@TransacDate,@TransacTime,@TotalAmount,@VAT,@VatableSales,@Discount,@DiscountType,@CashierName)"
                cmd = New OleDbCommand(sql, cn)
                With cmd
                    .Parameters.AddWithValue("@Transac_No", lblTransNo.Text)
                    .Parameters.AddWithValue("@TransacDate", lbldate.Text)
                    .Parameters.AddWithValue("@TransacTime", lbltime.Text)
                    .Parameters.AddWithValue("@TotalAmount", lblTotal.Text)
                    .Parameters.AddWithValue("@VAT", lblVAT.Text)
                    .Parameters.AddWithValue("@VatableSales", lblVSales.Text)
                    .Parameters.AddWithValue("@Discount", lblDiscount.Text)
                    .Parameters.AddWithValue("@DiscountType", cboDiscount.Text)
                    .Parameters.AddWithValue("@CashierName", lblCashier.Text)
                    .ExecuteNonQuery()
                End With
                'save details
                For Each i As ListViewItem In ListView1.Items
                    sql = "Insert into tblTransactionDetails(Transac_No,ProductCode,Amount,Quantity,Total)Values(@Transac_No,@ProductCode,@Amount,@Quantity,@Total)"
                    cmd = New OleDbCommand(sql, cn)
                    cmd.Parameters.AddWithValue("@Transac_No", lblTransNo.Text)
                    cmd.Parameters.AddWithValue("@ProductCode", i.Text) 'FIRST COLUMN OF THE LISTVIEW
                    cmd.Parameters.AddWithValue("@Amount", i.SubItems(2).Text) '3RD COLUMN
                    cmd.Parameters.AddWithValue("@Quantity", i.SubItems(3).Text) '4TH COLUMN
                    cmd.Parameters.AddWithValue("@Total", i.SubItems(4).Text) '5TH COLUMN
                    cmd.ExecuteNonQuery()
                Next
                'payments
                sql = "Insert into tblPayment(Transac_No,TotalAmount,AmountPaid,AmountChange,ModeofPayment,Reference_No)Values(@Transac_No,@TotalAmount,@AmountPaid,@AmountChange,@ModeofPayment,@Reference_No)"
                cmd = New OleDbCommand(sql, cn)
                cmd.Parameters.AddWithValue("@Transac_No", lblTransNo.Text)
                cmd.Parameters.AddWithValue("@TotalAmount", lblTotal.Text)
                cmd.Parameters.AddWithValue("@AmountPaid", lblAmountPaid.Text)
                cmd.Parameters.AddWithValue("@AmountChange", lblChange.Text)
                cmd.Parameters.AddWithValue("@ModeofPayment", lblMOP.Text)
                cmd.Parameters.AddWithValue("@Reference_No", lblRefNo.Text)
                cmd.ExecuteNonQuery()
                MsgBox("Transaction Successfully Saved", MsgBoxStyle.Information)
                ListView1.Items.Clear()
                Call resetCurrency()
            End If
        End If
        Call GetTransactionNo()
    End Sub
    Private Sub btnPayment_Click(sender As Object, e As EventArgs) Handles btnPayment.Click
        frmPay.Show()
        frmPay.lblGrandTotal.Text = Me.lblTotal.Text
    End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Call ResetText()
        Call ClearText()
        ListView1.Items.Clear()
        Call ResetCurrency()
    End Sub
    Private Sub btnOut_Click(sender As Object, e As EventArgs) Handles btnOut.Click
        If MsgBox("Log out account?", vbQuestion + vbYesNo) = vbYes Then
            MsgBox("GoodBye " & lblCashier.Text & "  " & " Have a nice day!!!", MsgBoxStyle.Information, "USER LOGOUT")

            Me.Hide()
            'frmLogin.Show()

        End If
    End Sub
    Private Sub ResetCurrency()
        lblAmountPaid.Text = "0.00"
        lblVAT.Text = "0.00"
        lblVSales.Text = "0.00"
        lblTotalItems.Text = "0.00"
        lblMOP.Text = "******"
        lblDiscount.Text = "0.00"
        lblRefNo.Text = "*****"
        lblTotal.Text = "0.00"
        lblChange.Text = "0.00"
    End Sub
    Private Sub GetTotal()
        Const col As Integer = 4 'subTotal column
        Dim total As Integer
        Dim lvsi As ListViewItem.ListViewSubItem
        For i As Integer = 0 To ListView1.Items.Count - 1
            lvsi = ListView1.Items(i).SubItems(col)
            total += Double.Parse(lvsi.Text)
        Next
        lblTotal.Text = Format(Val(total), "0.00")
    End Sub

    Private Sub GetTotalItem()
        Const col As Integer = 3 'quantity column
        Dim total As Integer
        Dim lvsi As ListViewItem.ListViewSubItem
        For i As Integer = 0 To ListView1.Items.Count - 1
            lvsi = ListView1.Items(i).SubItems(col)
            total += Double.Parse(lvsi.Text)
        Next
        lblTotalItems.Text = Val(total)
    End Sub
    Private Sub GetVAT()
        Dim vatableSales As Double
        vatableSales = lblTotal.Text / 1.12 'THE TOTAL AMOUNT DIVIDED BY 1.12
        lblVAT.Text = Format(Val(vatableSales), "0.00")
        lblVSales.Text = Val(lblTotal.Text) - Val(lblVAT.Text) 'THE RESULT OF VAT MINUS THE TOTAL AMOUNT

    End Sub

    Private Sub cboDiscount_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDiscount.SelectedIndexChanged
        Dim discount, newTotal As Double
        discount = Val(lblTotal.Text) * 0.2 'discount value is 20% 
        lblDiscount.Text = Format(Val(discount), "0.00")
        newTotal = Val(lblTotal.Text) - Val(lblDiscount.Text) 'COMPUTES THE NEW TOTAL OF THE ITEMS LESS THE DISCOUNTED PERCENTAGE
        lblTotal.Text = Format(Val(newTotal), "0.00") 'NEW TOTAL
        lblVAT.Text = "0.00" 'VAT EXEMPT
        lblVSales.Text = "0.00" 'VAT EXEMPT
    End Sub


End Class
