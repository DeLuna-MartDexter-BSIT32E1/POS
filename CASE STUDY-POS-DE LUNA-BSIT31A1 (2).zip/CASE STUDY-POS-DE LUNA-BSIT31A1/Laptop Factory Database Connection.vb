﻿Imports System.Data.OleDb

Module DatabaseConnection
    Public cn As New OleDbConnection
    Public cmd As OleDbCommand
    Public dr As OleDbDataReader
    Public sql As String

    Public Sub Connection()
        cn.Close()
        cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Dexter\Desktop\CASE STUDY-POS-DE LUNA-BSIT31A1\bin\x64\Debug\LaptopFactoryDatabase.accdb"
        cn.Open()
        'MsgBox("Connection Success")
    End Sub
End Module
