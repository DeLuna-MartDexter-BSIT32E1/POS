﻿Imports System.Data.OleDb

Public Class frmSalesReport
    Private Sub frmSalesReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call LoadSales()
    End Sub
    Private Sub LoadSales()
        sql = "Select Transac_No,TransacDate,TransacTime,TotalAmount,VAT,VatableSales,Discount,DiscountType,AmountPaid,AmountChange,ModeofPayment,Reference_No,CashierName from qrySales order by Transac_No asc"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        Dim x As ListViewItem
        ListView1.Items.Clear()
        Do While dr.Read = True
            x = New ListViewItem(dr(0).ToString)
            x.SubItems.Add(dr(1).ToString)
            x.SubItems.Add(dr(2).ToString)
            x.SubItems.Add(dr(3).ToString)
            x.SubItems.Add(dr(4).ToString)
            x.SubItems.Add(dr(5).ToString)
            x.SubItems.Add(dr(6).ToString)
            x.SubItems.Add(dr(7).ToString)
            x.SubItems.Add(dr(8).ToString)
            x.SubItems.Add(dr(9).ToString)
            x.SubItems.Add(dr(10).ToString)
            x.SubItems.Add(dr(11).ToString)
            x.SubItems.Add(dr(12).ToString)
            ListView1.Items.Add(x)
        Loop
        Call GetTotal()
    End Sub
    Private Sub GetTotal()
        Const col As Integer = 3
        Dim total As Integer
        Dim lvsi As ListViewItem.ListViewSubItem
        For i As Integer = 0 To ListView1.Items.Count - 1
            lvsi = ListView1.Items(i).SubItems(col)
            total += Double.Parse(lvsi.Text)
        Next
        lblTOTAL.Text = Format(Val(total), "0.00")
    End Sub

    Private Sub ListView1_MouseClick(sender As Object, e As MouseEventArgs) Handles ListView1.MouseClick
        If ListView1.Items.Count > 0 Then
            Dim i As ListViewItem = ListView1.SelectedItems(0)
            frmReportDetails.lblTransNo.Text = i.SubItems(0).Text
            frmReportDetails.Show()
        End If

    End Sub



End Class