﻿Imports System.Data.OleDb

Public Class frmPay
    Private Sub frmPay_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadMOP()
    End Sub
    Private Sub LoadMOP()
        sql = "Select distinct PaymentMode from tblPaymentMode where status='1'"
        cmd = New OleDbCommand(sql, cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        cboMOP.DataSource = dt
        cboMOP.DisplayMember = "PaymentMode"
    End Sub
    Private Sub cboMOP_SelectedIndexChanged(sender As Object, e As EventArgs)
        If cboMOP.Text = "Cash" Then
            txtRefNo.ReadOnly = True
            txtAmountPaid.Clear()
            txtAmountPaid.Enabled = True
        Else
            txtRefNo.ReadOnly = False
            txtAmountPaid.Text = lblGrandTotal.Text
            txtChange.Text = "0.00"
            txtAmountPaid.Enabled = False
        End If
    End Sub

    Private Sub txtAmountPaid_TextChanged(sender As Object, e As EventArgs)
        Dim change As Double
        change = Val(txtAmountPaid.Text) - Val(lblGrandTotal.Text)
        txtChange.Text = Format(Val(change), "0.00")
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs)
        If Val(txtAmountPaid.Text) < Val(lblGrandTotal.Text) Then
            MsgBox("Insufficient Payment", MsgBoxStyle.Critical)
        Else
            frmPOSdashboard.lblAmountPaid.Text = Me.txtAmountPaid.Text
            frmPOSdashboard.lblChange.Text = Me.txtChange.Text
            frmPOSdashboard.lblMOP.Text = Me.cboMOP.Text
            frmPOSdashboard.lblRefNo.Text = Me.txtRefNo.Text
            Me.Close()
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Dim a As String = InputBox("Enter mode of payment")
        sql = "Insert into tblpaymentmode(paymentmode,status)values(@paymentmode,@status)"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@paymentmode", a)
            .Parameters.AddWithValue("@status", "1")
            .ExecuteNonQuery()
        End With
    End Sub
End Class