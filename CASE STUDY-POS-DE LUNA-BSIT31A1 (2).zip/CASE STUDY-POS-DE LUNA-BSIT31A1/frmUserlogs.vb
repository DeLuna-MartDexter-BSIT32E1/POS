﻿Imports System.Data.OleDb

Public Class frmUserlogs
    Private Sub frmUserlogs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call LoadUserLogs()
    End Sub
    Private Sub LoadUserLogs()
        sql = "Select * from tblUserLogs where Username = @Username"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            cmd.Parameters.AddWithValue("@Username", frmLoginForm.txtusername.Text)
        End With
        dr = cmd.ExecuteReader
        Dim x As ListViewItem
        ListView1.Items.Clear()
        Do While dr.Read = True
            x = New ListViewItem(dr("Log_ID").ToString)
            x.SubItems.Add(dr("Username").ToString)
            x.SubItems.Add(dr("Accesslevel").ToString)
            x.SubItems.Add(dr("DateX").ToString)
            x.SubItems.Add(dr("TimeIn").ToString)
            x.SubItems.Add(dr("TimeOut").ToString)
            ListView1.Items.Add(x)
        Loop
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        Call LoadUserLogs()
    End Sub
End Class