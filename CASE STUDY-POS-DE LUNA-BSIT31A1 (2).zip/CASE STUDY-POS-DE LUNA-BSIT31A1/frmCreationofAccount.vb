﻿Imports System.Data.OleDb

Public Class frmCreationofAccount
    Private Sub frmCreationofAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
    End Sub

    Private Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click
        sql = "Select Username from tblAccounts where Username='" & txtusername.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.HasRows = True Then
            MsgBox("Username already exist", MsgBoxStyle.Information, "Information")
        ElseIf txtpassword.Text <> txtconfirmpassword.Text Then
            MsgBox("Password Mismatch", MsgBoxStyle.Critical, "Error")
        ElseIf txtpassword.TextLength < 6 And txtconfirmpassword.TextLength < 6 Then
            MsgBox("Password must be more than 6 characters", MsgBoxStyle.Critical, "Error")
        Else
            If String.IsNullOrEmpty(txtfirstname.Text) OrElse
               String.IsNullOrEmpty(txtlastname.Text) OrElse
               String.IsNullOrEmpty(txtusername.Text) OrElse
               String.IsNullOrEmpty(txtpassword.Text) OrElse
               String.IsNullOrEmpty(cboaccesslevel.Text) Then
                MessageBox.Show("Please fill in all the required fields.", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return ' Stop further execution
            Else
                ' Call SaveData() only if the username doesn't exist
                Call SaveData()
                txtlastname.Clear()
                txtfirstname.Clear()
                txtusername.Clear()
                txtpassword.Clear()
                txtconfirmpassword.Clear()
            End If
        End If
    End Sub
    Private Sub SaveData()
        sql = "Insert into tblAccounts ([Username],[Password],[Accesslevel],[Lastname],[Firstname],[Status])values([@Username],[@Password],[@Accesslevel],[@Lastname],[@Firstname],[@Status])"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("[@Username]", txtusername.Text)
            .Parameters.AddWithValue("[@Password]", txtpassword.Text)
            .Parameters.AddWithValue("[@Accesslevel]", cboaccesslevel.Text)
            .Parameters.AddWithValue("[@Lastname]", txtlastname.Text)
            .Parameters.AddWithValue("[@Firstname]", txtfirstname.Text)
            .Parameters.AddWithValue("[@Status]", "Active")
            .ExecuteNonQuery()
        End With
        MsgBox("New Record Success", MsgBoxStyle.Information, "Information")
        Me.Close()
    End Sub

End Class